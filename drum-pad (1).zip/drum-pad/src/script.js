function play1()
{
  var audio = document.getElementById("audio1");
  audio.play();
}
function play2()
{
  var audio = document.getElementById("audio2");
  audio.play();
}
function play3()
{
  var audio = document.getElementById("audio3");
  audio.play();
}
function play4()
{
  var audio = document.getElementById("audio4");
  audio.play();
}
function play5()
{
  var audio = document.getElementById("audio5");
  audio.play();
}
function play6()
{
  var audio = document.getElementById("audio6");
  audio.play();
}

